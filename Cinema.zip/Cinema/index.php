<?php
header('Content-Type: application/xml; charset=utf-8');

if (!isset($_GET["METHOD_"]))
    Errore("non hai passato il method");

if ($_GET["METHOD_"] == "GET") {
    //select
    if (!isset($_GET["Tabella"]))
        Errore("non hai passato la tabella da visualizzare");

    if ($_GET["Tabella"] == "Attori")
        Select($_GET["Tabella"]);
}

if ($_GET["METHOD_"] == "PUT") {

    if (!isset($_GET["azione"])) // AZIONE indica cosa si vuole andare a fare (CF = crea film, MF = modifica film, AA = associa attore ...)
        Errore("non hai passato l'azione che vuoi compiere'");

    if ($_GET["azione"] == "MF") {
        $domtree = new DOMDocument('1.0', 'UTF-8');
        //creo la root
        $xmlRoot = $domtree->createElement("root");
        //la aggiungo al documento
        $xmlRoot = $domtree->appendChild($xmlRoot);

        $conn = Connessione();

        if (isset($_GET["Titolo"])) {
            $stmt = $conn->prepare("UPDATE film SET Titolo=? WHERE CodFilm = " . $_GET["codfilm"] . "");
            $stmt->bind_param("s", $_GET["Titolo"]);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'titolo modificato'));
        }
     
        if (isset($_GET["Nazionalita"])) {
            $stmt = $conn->prepare("UPDATE film SET Nazionalita=? WHERE CodFilm = " . $_GET["codfilm"] . "");
            $stmt->bind_param("s", $_GET["Nazionalita"]);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'nazionalita modificato'));
        }
        if (isset($_GET["Regista"])) {
            $stmt = $conn->prepare("UPDATE film SET Regista=? WHERE CodFilm = " . $_GET["codfilm"] . "");
            $stmt->bind_param("s", $_GET["Regista"]);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'regista modificato'));
        }
        if (isset($_GET["Genere"])) {
            $stmt = $conn->prepare("UPDATE film SET Genere=? WHERE CodFilm = " . $_GET["codfilm"] . "");
            $stmt->bind_param("s", $_GET["Genere"]);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'genere modificato'));
        }
        if (isset($_GET["Durata"])) {
            $stmt = $conn->prepare("UPDATE film SET Durata=? WHERE CodFilm = " . $_GET["codfilm"] . "");
            $stmt->bind_param("i", $_GET["Durata"]);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'durata modificato'));
        }
        if (isset($_GET["Anno"])) {
                $stmt = $conn->prepare("UPDATE film SET AnnoProduzione=? WHERE CodFilm = " . $_GET["codfilm"] . "");
            $stmt->bind_param("i", $_GET["Anno"]);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'anno modificato'));
        }
        //visualizzo l'xml 
        echo $domtree->saveXML();
    }

    if($_GET["azione"] == "MP"){
        $domtree = new DOMDocument('1.0', 'UTF-8');
        //creo la root
        $xmlRoot = $domtree->createElement("root");
        //la aggiungo al documento
        $xmlRoot = $domtree->appendChild($xmlRoot);

        $conn = Connessione();

        if (isset($_GET["codfilm"])) {
            $stmt = $conn->prepare("UPDATE proiezioni SET CodFilm=? WHERE CodProiezione = " . $_GET["codproiezione"] . "");
            $CodFilm = $_GET["codfilm"];
            $stmt->bind_param("i", $CodFilm);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'CodFilm modificato'));
        } 
        if (isset($_GET["codsala"])) {
            $stmt = $conn->prepare("UPDATE proiezioni SET CodSala=? WHERE CodProiezione = " . $_GET["codproiezione"] . "");
            $CodSala = $_GET["codsala"];
            $stmt->bind_param("i", $CodSala);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'CodSala modificato'));
        }
        if (isset($_GET["incasso"])) {
            $stmt = $conn->prepare("UPDATE proiezioni SET Incasso=? WHERE CodProiezione = " . $_GET["codproiezione"] . "");
            $Incasso = $_GET["incasso"];
            $stmt->bind_param("i", $Incasso);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'CodFilm modificato'));
        }
        if (isset($_GET["dataproiezione"])) {
            $stmt = $conn->prepare("UPDATE proiezioni SET dataproiezione=? WHERE CodProiezione = " . $_GET["codproiezione"] . "");
            $Data = $_GET["dataproiezione"];
            $stmt->bind_param("i", $Data);
            $stmt->execute();
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'CodFilm modificato'));
        }
        //visualizzo l'xml 
        echo $domtree->saveXML();
    }
}

if ($_GET["METHOD_"] == "POST") 
{
    if (!isset($_GET["azione"])) // AZIONE indica cosa si vuole andare a fare (CF = crea film, MF = modifica film, AA = associa attore ...)
        Errore("non hai passato l'azione che vuoi compiere'");

    if ($_GET["azione"] == "CF") {
        //creo la connessione al db
        $conn = Connessione();

        $titolo = $_GET["Titolo"];
        $anno = $_GET["Anno"];
        $nazionalita = $_GET["Nazionalita"];
        $regista = $_GET["Regista"];
        $genere = $_GET["Genere"];
        $durata = $_GET["Durata"];

        //if(isset($_SESSION["admin"])){
        $stmt = $conn->prepare("INSERT INTO film (Titolo, AnnoProduzione, Nazionalita, Regista, Genere, Durata) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("sisssi", $titolo, $anno, $nazionalita, $regista, $genere, $durata);

        $stmt->execute();

        $domtree = new DOMDocument('1.0', 'UTF-8');
        //creo la root
        $xmlRoot = $domtree->createElement("root");
        //la aggiungo al documento
        $xmlRoot = $domtree->appendChild($xmlRoot);
        //aggiungo elementi...
        $currentTrack = $domtree->createElement("msg");
        $currentTrack = $xmlRoot->appendChild($currentTrack);
        $currentTrack->appendChild($domtree->createElement('success', 'true'));
        $currentTrack->appendChild($domtree->createElement('messages', 'film creato'));

        //visualizzo l'xml 
        echo $domtree->saveXML();
    }

    if ($_GET["azione"] == "AA") {

        if(isset($_GET["codattore"]) && isset($_GET["codfilm"]))
        {
            $conn = Connessione();
            $stmt = $conn->prepare("INSERT INTO recita (CodAttore, CodFilm) VALUES (?,?)");
            $stmt->bind_param("ii",$_GET["codattore"], $_GET["codfilm"]);
    
            $stmt->execute();
    
            $domtree = new DOMDocument('1.0', 'UTF-8');
            //creo la root
            $xmlRoot = $domtree->createElement("root");
            //la aggiungo al documento
            $xmlRoot = $domtree->appendChild($xmlRoot);
            //aggiungo elementi...
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'Attore associato'));
        }
    }

    if($_GET["azione"] == "CP"){
        //creo la connessione al db
        $conn = Connessione();

        $CodFilm = $_GET["codfilm"];
        $CodSala = $_GET["codsala"];
        $Incasso = $_GET["incasso"];
        $DataProiezione = $_GET["data"];

        //if(isset($_SESSION["admin"])){
        $stmt = $conn->prepare("INSERT INTO proiezioni (CodFilm, CodSala, Incasso, DataProiezione) VALUES (?,?,?,?)");
        $stmt->bind_param("iiii", $CodFilm, $CodSala, $Incasso, $DataProiezione);
        $stmt->execute();

        $domtree = new DOMDocument('1.0', 'UTF-8');
        //creo la root
        $xmlRoot = $domtree->createElement("root");
        //la aggiungo al documento
        $xmlRoot = $domtree->appendChild($xmlRoot);
        //aggiungo elementi...
        $currentTrack = $domtree->createElement("msg");
        $currentTrack = $xmlRoot->appendChild($currentTrack);
        $currentTrack->appendChild($domtree->createElement('success', 'true'));
        $currentTrack->appendChild($domtree->createElement('messages', 'proiezione creata'));

        //visualizzo l'xml 
        echo $domtree->saveXML();
    }
}

if ($_GET["METHOD_"] == "DELETE")
{
    if (!isset($_GET["azione"])) // AZIONE indica cosa si vuole andare a fare (CF = crea film, MF = modifica film, AA = associa attore ...)
        Errore("non hai passato l'azione che vuoi compiere'");

    if ($_GET["azione"] == "RF") {
            if (!isset($_GET["id"]))
                Errore("id inesistente");
    
            //creo la connessione al db
            $conn = Connessione();
            $stmt = $conn->prepare("DELETE FROM film WHERE CodFilm = " . $_GET["id"] . "");
    
            $stmt->execute();
    
    
            $domtree = new DOMDocument('1.0', 'UTF-8');
    
            //creo la root
            $xmlRoot = $domtree->createElement("root");
            //la aggiungo al documento
            $xmlRoot = $domtree->appendChild($xmlRoot);
            //aggiungo elementi...
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'film eliminato'));
    
            //visualizzo l'xml 
            echo $domtree->saveXML();
    }
    
    if ($_GET["azione"] == "RA") {
        $conn = Connessione();
        if(isset($_GET["codattore"]) && isset($_GET["codfilm"]))
        {
            $conn = Connessione();
            $stmt = $conn->prepare("DELETE FROM recita WHERE CodAttore = " . $_GET["codattore"] . " AND CodFilm = " . $_GET["codfilm"] . "");
            $stmt->execute();
    
            $domtree = new DOMDocument('1.0', 'UTF-8');
            //creo la root
            $xmlRoot = $domtree->createElement("root");
            //la aggiungo al documento
            $xmlRoot = $domtree->appendChild($xmlRoot);
            //aggiungo elementi...
            $currentTrack = $domtree->createElement("msg");
            $currentTrack = $xmlRoot->appendChild($currentTrack);
            $currentTrack->appendChild($domtree->createElement('success', 'true'));
            $currentTrack->appendChild($domtree->createElement('messages', 'Assocciazione rimossa'));
        }
    }

    if($_GET["azione"] == "RP"){
        if (!isset($_GET["proiezione"]))
            Errore("id inesistente");

        //creo la connessione al db
        $conn = Connessione();
        $stmt = $conn->prepare("DELETE FROM proiezioni WHERE CodProiezione = " . $_GET["proiezione"] . " ");

        $stmt->execute();


        $domtree = new DOMDocument('1.0', 'UTF-8');

        //creo la root
        $xmlRoot = $domtree->createElement("root");
        //la aggiungo al documento
        $xmlRoot = $domtree->appendChild($xmlRoot);
        //aggiungo elementi...
        $currentTrack = $domtree->createElement("msg");
        $currentTrack = $xmlRoot->appendChild($currentTrack);
        $currentTrack->appendChild($domtree->createElement('success', 'true'));
        $currentTrack->appendChild($domtree->createElement('messages', 'film eliminato'));

        //visualizzo l'xml 
        echo $domtree->saveXML();
    }

}

function Select($tabella)
{
    //creo la connessione al db

    $conn = Connessione();

    $domtree = new DOMDocument('1.0', 'UTF-8');
    //creo la root
    $xmlRoot = $domtree->createElement("root");
    //la aggiungo al documento
    $xmlRoot = $domtree->appendChild($xmlRoot);

    $stmt = $conn->prepare("SELECT * FROM $tabella WHERE 1");

    $stmt->execute();
    $result = $stmt->get_result();

    for ($i = 0; $i < $result->num_rows; $i++) {
        if ($result->num_rows > 0) {
            if ($row = $result->fetch_assoc()) {
                $currentTrack = $domtree->createElement("attore");
                $currentTrack = $xmlRoot->appendChild($currentTrack);
                $currentTrack->appendChild($domtree->createElement('success', 'true'));
                $currentTrack->appendChild($domtree->createElement('nome', $row["Nome"]));
                $currentTrack->appendChild($domtree->createElement('anno', $row["AnnoNascita"]));
                $currentTrack->appendChild($domtree->createElement('nazionalita', $row["Nazionalita"]));
            }
        }
    }

    echo $domtree->saveXML();
}

function Errore($msg)
{
    $domtree = new DOMDocument('1.0', 'UTF-8');

    //creo la root
    $xmlRoot = $domtree->createElement("root");
    //la aggiungo al documento
    $xmlRoot = $domtree->appendChild($xmlRoot);



    //aggiungo elementi...
    $currentTrack = $domtree->createElement("msg");
    $currentTrack = $xmlRoot->appendChild($currentTrack);
    $currentTrack->appendChild($domtree->createElement('success', 'false'));
    $currentTrack->appendChild($domtree->createElement('messages', $msg));

    //visualizzo l'xml 
    echo $domtree->saveXML();
    die();
}

function Connessione()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "5aiAAA_dbprenotazionecinema";

    $conn = new mysqli($servername, $username, $password, $dbname);
    return $conn;
}