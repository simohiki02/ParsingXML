/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinemaws;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author
 */
public class CinemaWS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
        // TODO code application logic here
        FileWriter fw = new FileWriter("Film.xml");
        
        URL url = new URL ("http://localhost/AAA/Tecno/");
        
        Scanner sc = new Scanner(url.openStream());
        sc.useDelimiter("\u001a");     
  
        fw.write(sc.next());
        
        fw.flush();
        fw.close();
        
        gestore g = new gestore("Film.xml");
        g.creaLista();
    }
    
}
